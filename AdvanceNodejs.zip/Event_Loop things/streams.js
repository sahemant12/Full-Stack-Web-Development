const express = require('express')
const app = express()
const fs = require('fs')

app.use('/',(req,res)=>{

    const rstream = fs.createReadStream('notes.txt')

    // rstream.on('data', (chunksdata)=>{
    //     res.write(chunksdata)
    // })
    // rstream.on('end', ()=>{
    //     res.end()
    // })
    // rstream.on('error', (err)=>{
    //     console.log(err)
    //     res.end("file not found")
    // })
    rstream.pipe(res)
})

app.listen(8080,()=>{
    console.log("app is listening")
})