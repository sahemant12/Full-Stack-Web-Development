// Events Module: Node.js has a built in module called 'Events', where we can create, fire, listen for our own events.

const EventEmitter = require('events')
const event = new EventEmitter()

event.on('sayMyName', ()=>{
    console.log("My name is Hemant SAh")
})  //with same event name we can display different code

event.on('sayMyName', ()=>{
    console.log("My name is himanshu SAh")
})

event.on('sayMyName', ()=>{
    console.log("My name is krishna SAh")
})

event.emit('sayMyName') //we can create our own event by the help of emit.


event.on('checkpage',(status, msg)=>{ // listeners
    console.log(`my status is ${status} and I'm ${msg}` )
})
//syntax
// em.emit( eventName , payloadData ) // emit events
event.emit('checkpage', 200, 'ok')