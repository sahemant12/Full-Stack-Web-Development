
function func2(){
    setTimeout(() => {
        console.log("func2 is started")
    }, 3000);
}

function func1(){
    console.log("func1 is started")
    func2()
    console.log("func1 is end")
}

func1()
//output: func1 is started
//        func1 is end
//        func2 is started